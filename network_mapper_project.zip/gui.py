"""
Network Health & Topology Mapper - Python GUI
This GUI will:
 - load a list of target IPs (devices.json)
 - call the compiled C scanner (snmp_scan) per device (or use fallback)
 - visualize topology using networkx + matplotlib
 - show discovered devices, metrics, alerts, logs
 - allow downloading logs and exporting the log folder as zip
"""
import sys, os, json, subprocess, threading, time, datetime
from pathlib import Path
from PyQt5 import QtWidgets, QtCore
from PyQt5.QtWidgets import QApplication, QWidget, QListWidgetItem, QMessageBox, QFileDialog
import networkx as nx
import matplotlib
matplotlib.use("Qt5Agg")
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt
import logging
import zipfile

BASE = Path(__file__).resolve().parent
LOG_DIR = BASE / "logs"
LOG_DIR.mkdir(exist_ok=True)
logging.basicConfig(filename=str(LOG_DIR/"project.log"), level=logging.INFO, format='%(asctime)s %(levelname)s: %(message)s')

DEVICES_FILE = BASE / "devices.json"
C_SCANNER = BASE / "snmp_scan"  # compiled C binary

# Load or create devices list
if not DEVICES_FILE.exists():
    sample = [
        {"name":"Router-01","ip":"192.168.1.1","community":"public"},
        {"name":"Switch-01","ip":"192.168.1.2","community":"public"},
        {"name":"Server-App","ip":"192.168.1.10","community":"public"},
        {"name":"Printer-01","ip":"192.168.1.50","community":"public"},
        {"name":"Workstation-07","ip":"192.168.1.110","community":"public"}
    ]
    DEVICES_FILE.write_text(json.dumps(sample, indent=2))

def run_c_scan(ip, community, timeout=6):
    # runs snmp_scan binary and captures json output. If the binary doesn't exist, return simulated data.
    if C_SCANNER.exists():
        try:
            proc = subprocess.run([str(C_SCANNER), ip, community], capture_output=True, text=True, timeout=timeout)
            if proc.returncode == 0:
                return json.loads(proc.stdout)
            else:
                logging.error("C scanner error for %s: %s", ip, proc.stderr.strip())
                return {"ip":ip,"error":proc.stderr.strip(), "anomalies":["scanner_error"]}
        except Exception as e:
            logging.exception("Exception running C scanner")
            return {"ip":ip,"error":str(e), "anomalies":["scanner_exception"]}
    else:
        # Fallback simulated
        logging.warning("C scanner not found, using simulated data for %s", ip)
        return {"ip":ip,"sysName":"sim-"+ip,"sysUpTime":"123456","interfaces":[{"descr":"eth0","oper":1}], "if_count":1,"interfaces_down":0,"memory_percent":30,"anomalies":[]}

class TopologyCanvas(FigureCanvas):
    def __init__(self, parent=None):
        fig, self.ax = plt.subplots(figsize=(6,6))
        super().__init__(fig)
        self.setParent(parent)
        self.G = nx.Graph()

    def draw_topology(self, devices, links):
        self.ax.clear()
        self.G.clear()
        for d in devices:
            self.G.add_node(d["name"])
        for a,b in links:
            self.G.add_edge(a,b)
        pos = nx.spring_layout(self.G, seed=2)
        nx.draw(self.G, pos, with_labels=True, node_size=800, ax=self.ax, node_color=None, edge_color='gray')
        self.draw()

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Network Health & Topology Mapper")
        self.resize(1100,600)
        layout = QtWidgets.QHBoxLayout(self)

        # Left: discovered devices
        self.left = QtWidgets.QWidget()
        left_layout = QtWidgets.QVBoxLayout(self.left)
        left_layout.addWidget(QtWidgets.QLabel("Discovered Devices"))
        self.dev_list = QtWidgets.QListWidget()
        left_layout.addWidget(self.dev_list)
        self.scan_btn = QtWidgets.QPushButton("Scan Network")
        left_layout.addWidget(self.scan_btn)
        self.export_logs_btn = QtWidgets.QPushButton("Download Logs")
        left_layout.addWidget(self.export_logs_btn)
        layout.addWidget(self.left,1)

        # Center: topology
        self.center = QtWidgets.QWidget()
        center_layout = QtWidgets.QVBoxLayout(self.center)
        center_layout.addWidget(QtWidgets.QLabel("Topology (visual)"))
        self.canvas = TopologyCanvas(self)
        center_layout.addWidget(self.canvas)
        layout.addWidget(self.center,2)

        # Right: metrics & alerts
        self.right = QtWidgets.QWidget()
        right_layout = QtWidgets.QVBoxLayout(self.right)
        right_layout.addWidget(QtWidgets.QLabel("Metrics & Alerts"))
        self.metrics_box = QtWidgets.QTextEdit()
        self.metrics_box.setReadOnly(True)
        right_layout.addWidget(self.metrics_box)
        layout.addWidget(self.right,1)

        # Load devices
        self.devices = json.loads(DEVICES_FILE.read_text())
        self.refresh_device_list()

        # Signals
        self.scan_btn.clicked.connect(self.scan_network)
        self.dev_list.itemDoubleClicked.connect(self.inspect_device)
        self.export_logs_btn.clicked.connect(self.export_logs)

        # simple topology links placeholder
        self.links = [("Router-01","Switch-01"),("Router-01","Server-App"),("Switch-01","Printer-01"),("Switch-01","Workstation-07"),("Router-01","Workstation-07")]
        self.canvas.draw_topology(self.devices, self.links)

    def refresh_device_list(self):
        self.dev_list.clear()
        for d in self.devices:
            item = QListWidgetItem(f"{d['name']}\\n{d['ip']}")
            item.setData(QtCore.Qt.UserRole, d)
            self.dev_list.addItem(item)

    def scan_network(self):
        self.metrics_box.append(f"Starting scan at {datetime.datetime.now()}\\n")
        logging.info("Starting full network scan")
        # run scans in background threads
        threads = []
        results = []
        lock = threading.Lock()
        def worker(dev):
            res = run_c_scan(dev['ip'], dev.get('community','public'))
            res['name'] = dev['name']
            with lock:
                results.append(res)
                logging.info("Scan result for %s: %s", dev['ip'], json.dumps(res)[:200])
            # UI updates must be on main thread - use signal/queue via QTimer singleShot
            QtCore.QTimer.singleShot(0, lambda r=res: self.handle_scan_result(r))
        for dev in self.devices:
            t = threading.Thread(target=worker, args=(dev,))
            t.start()
            threads.append(t)
        # not joining threads here to keep UI responsive

    def handle_scan_result(self, res):
        # update device list marker
        ip = res.get('ip')
        name = res.get('name', ip)
        anomalies = res.get('anomalies', [])
        # show popup if anomaly
        if anomalies:
            msg = QMessageBox(self)
            msg.setWindowTitle("Critical Alert")
            msg.setText(f"Device {name} ({ip}) reported anomalies: {', '.join(anomalies)}")
            msg.setIcon(QMessageBox.Warning)
            msg.exec_()
            logging.warning("Anomaly for %s: %s", ip, anomalies)
        # update metrics panel
        s = f"{name} ({ip})\\n"
        if res.get('memory_percent') is not None:
            s += f"Memory: {res.get('memory_percent')}%\\n"
        s += f"Interfaces: {res.get('if_count',0)}, down: {res.get('interfaces_down',0)}\\n"
        s += f"Anomalies: {', '.join(res.get('anomalies',[]))}\\n"
        s += "------\\n"
        self.metrics_box.append(s)

    def inspect_device(self, item):
        d = item.data(QtCore.Qt.UserRole)
        ip = d['ip']
        # run a single scan synchronously (quick)
        res = run_c_scan(ip, d.get('community','public'), timeout=8)
        text = json.dumps(res, indent=2)
        dlg = QtWidgets.QMessageBox(self)
        dlg.setWindowTitle(f"Device {d['name']} - {ip}")
        dlg.setText(text)
        dlg.exec_()

    def export_logs(self):
        # create zip of logs folder and prompt user where to save
        default = str(Path.home() / "network_logs.zip")
        dest, _ = QFileDialog.getSaveFileName(self, "Save logs as...", default, "Zip files (*.zip)")
        if not dest:
            return
        with zipfile.ZipFile(dest, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
            for f in LOG_DIR.iterdir():
                zf.write(f, arcname=f.name)
        QMessageBox.information(self, "Export Complete", f"Logs exported to {dest}")
        logging.info("User exported logs to %s", dest)

def main():
    app = QApplication(sys.argv)
    w = MainWindow()
    w.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
