# Network Health & Topology Mapper (SNMP) - Project Skeleton

## What this package contains
- `snmp_scan.c` — C SNMP scanner that queries basic OIDs and reports JSON.
- `snmp_scan` — (not included precompiled) compile from source.
- `gui.py` — PyQt5 GUI that integrates the C scanner output, visualizes topology, and shows alerts.
- `devices.json` — sample device list to scan.
- `logs/` — folder where runtime logs are stored.
- `build_and_run.sh` — helper script to install deps and compile.
- `requirements.txt` — Python package requirements.

## Key features implemented
- C scanner (uses Net-SNMP) to query sysName, sysUpTime, interface descriptions and oper status, memory usage.
- Simple anomaly detection: interfaces down, memory > 80%.
- Python GUI (PyQt5): device list, topology (networkx + matplotlib), metrics, pop-up alerts for anomalies, export logs as zip.
- Logging of scan events to `logs/project.log`.

## Step-by-step setup on Ubuntu (in your VM)
1. Open terminal in Ubuntu.
2. Copy project to a working directory, e.g. `~/network_mapper` or extract the provided zip.
3. Make build script executable:
   ```bash
   chmod +x build_and_run.sh
   ./build_and_run.sh
   ```
   (The script installs `libsnmp-dev`, `snmp`, and compiles `snmp_scan`. You may need `sudo`.)
4. If compilation fails, try:
   ```bash
   gcc snmp_scan.c -o snmp_scan -lnetsnmp
   ```
5. Run the GUI:
   ```bash
   python3 gui.py
   ```
6. In the GUI click **Scan Network**. If `snmp_scan` binary is present the GUI will call it; otherwise it uses simulated fallback data.

## How to connect devices and enable SNMP
- **VM network mode**: Use *Bridged Adapter* in VirtualBox so the VM is on the same LAN as other physical devices. Alternatively, Host-Only + port forwarding only for lab testing.
- **Linux device**: install and configure `snmpd`:
  ```bash
  sudo apt install snmpd
  sudo dpkg-reconfigure snmpd   # or edit /etc/snmp/snmpd.conf to set rocommunity public and listen on 0.0.0.0
  sudo systemctl restart snmpd
  ```
- **Windows**: Install SNMP feature (older Windows) or use third-party SNMP agent.
- **Routers/Switches** (Cisco example):
  ```
  configure terminal
  snmp-server community public RO
  end
  write memory
  ```
- **Printer / IoT devices**: Enable SNMP via device web UI or admin panel; set community string (commonly `public` for read-only in labs).
- **Testing connectivity**:
  ```bash
  # basic ping
  ping -c 1 192.168.1.1

  # test SNMP (snmpwalk must be installed: sudo apt install snmp)
  snmpwalk -v2c -c public 192.168.1.1 system
  snmpget -v2c -c public 192.168.1.1 .1.3.6.1.2.1.1.5.0
  ```

## Security notes
- `public` community is default and insecure. Use unique community strings in real deployments.
- Restrict SNMP access via firewall rules or ACLs.

## Extending the project (ideas)
- Add continuous background scanning and time-series metrics.
- Support SNMPv3 for secure authentication and encryption.
- Add port scanning and MAC discovery via LLDP/CDP.
- Store logs into sqlite and present queryable history in GUI.

## Troubleshooting
- If `snmp_scan` shows `Failed to open SNMP session`: check network connectivity and community string.
- If GUI cannot import PyQt5 on Ubuntu: ensure you installed system packages or use a virtualenv.

--- End of README
