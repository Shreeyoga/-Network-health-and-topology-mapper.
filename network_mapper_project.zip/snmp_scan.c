/*
 * snmp_scan.c
 * Simple SNMP scanner using Net-SNMP library.
 *
 * Usage:
 *   gcc snmp_scan.c -o snmp_scan -lnetsnmp -lnetsnmpagent -lnetsnmphelpers
 *   ./snmp_scan <target_ip> <community>
 *
 * Outputs a single JSON object on stdout with fields:
 *  - ip, sysName, sysUpTime, interfaces (array), memory_percent, anomalies (array)
 *
 * Note: This is a compact example — production code requires more error handling.
 */

#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* helper to run a GET and return string */
char *snmp_get_str(netsnmp_session *ss, const char *oid_str) {
    oid anOID[MAX_OID_LEN];
    size_t anOID_len = MAX_OID_LEN;
    netsnmp_pdu *pdu, *response;
    netsnmp_variable_list *vars;
    int status;
    char *result = NULL;

    if (!snmp_parse_oid(oid_str, anOID, &anOID_len)) return NULL;
    pdu = snmp_pdu_create(SNMP_MSG_GET);
    snmp_add_null_var(pdu, anOID, anOID_len);

    status = snmp_synch_response(ss, pdu, &response);
    if (status == STAT_SUCCESS && response && response->variables) {
        vars = response->variables;
        if (vars->type == ASN_OCTET_STR) {
            int len = vars->val_len;
            result = (char *)malloc(len + 1);
            memcpy(result, vars->val.string, len);
            result[len] = 0;
        } else {
            /* convert non-string to printable */
            char buf[256];
            snprint_value(buf, sizeof(buf), vars->name, vars->name_length, vars);
            result = strdup(buf);
        }
    }
    if (response) snmp_free_pdu(response);
    return result;
}

/* helper to walk and count interfaces and detect status */
int snmp_walk_interfaces(netsnmp_session *ss, char **out_json_parts, int *parts_count, int *interfaces_down) {
    netsnmp_pdu *pdu, *response;
    oid ifDescrOid[] = {1,3,6,1,2,1,2,2,1,2}; /* ifDescr */
    oid ifOperOid[]  = {1,3,6,1,2,1,2,2,1,8}; /* ifOperStatus */
    size_t ifDescrLen = OID_LENGTH(ifDescrOid);
    size_t ifOperLen = OID_LENGTH(ifOperOid);
    int status;
    netsnmp_variable_list *vars;
    oid name[MAX_OID_LEN];
    size_t name_len;
    oid cur_oid[MAX_OID_LEN];
    size_t cur_oid_len;

    /* Walk ifDescr to get descriptions */
    memcpy(cur_oid, ifDescrOid, sizeof(ifDescrOid));
    cur_oid_len = ifDescrLen;

    pdu = snmp_pdu_create(SNMP_MSG_GETNEXT);
    snmp_add_null_var(pdu, cur_oid, cur_oid_len);

    int idx = 0;
    while (1) {
        if (response) { snmp_free_pdu(response); response = NULL; }
        status = snmp_synch_response(ss, pdu, &response);
        if (status != STAT_SUCCESS || !response) break;
        vars = response->variables;
        if (!vars) break;

        /* check if still under ifDescr subtree */
        if (snmp_oid_compare(ifDescrOid, ifDescrLen, vars->name, vars->name_length) != 0) {
            /* left subtree */
            break;
        }

        char descr[256] = {0};
        if (vars->type == ASN_OCTET_STR) {
            int len = vars->val_len > 255 ? 255 : vars->val_len;
            memcpy(descr, vars->val.string, len);
            descr[len] = 0;
        } else {
            snprint_value(descr, sizeof(descr), vars->name, vars->name_length, vars);
        }

        /* get corresponding ifOperStatus by replacing last subid with .8 (operStatus column index) */
        oid oper_oid[MAX_OID_LEN];
        memcpy(oper_oid, vars->name, vars->name_length * sizeof(oid));
        oper_oid[vars->name_length - 1] = 8;
        size_t oper_oid_len = vars->name_length;

        netsnmp_pdu *pdu2 = snmp_pdu_create(SNMP_MSG_GET);
        snmp_add_null_var(pdu2, oper_oid, oper_oid_len);
        netsnmp_pdu *response2 = NULL;
        int st2 = snmp_synch_response(ss, pdu2, &response2);
        int oper_status = -1;
        if (st2 == STAT_SUCCESS && response2 && response2->variables) {
            netsnmp_variable_list *v2 = response2->variables;
            if (v2->type == ASN_INTEGER || v2->type == ASN_UNSIGNED) {
                oper_status = *(v2->val.integer);
            }
        }
        if (response2) snmp_free_pdu(response2);

        char part[512];
        snprintf(part, sizeof(part), "{\"descr\":\"%s\",\"oper\":%d}", descr, oper_status);
        out_json_parts[(*parts_count)++] = strdup(part);
        if (oper_status != 1) (*interfaces_down)++;
        idx++;

        /* prepare next GETNEXT from last returned oid */
        pdu = snmp_pdu_create(SNMP_MSG_GETNEXT);
        snmp_add_null_var(pdu, vars->name, vars->name_length);
    }

    if (response) snmp_free_pdu(response);
    return idx;
}

int main(int argc, char **argv) {
    if (argc < 3) {
        fprintf(stderr, "Usage: %s <target_ip> <community>\\n", argv[0]);
        return 2;
    }
    char *target = argv[1];
    char *community = argv[2];

    // Initialize SNMP
    init_snmp("snmp_scan");
    netsnmp_session session, *ss;
    snmp_sess_init(&session);
    session.peername = target;
    session.version = SNMP_VERSION_2c;
    session.community = (u_char*)community;
    session.community_len = strlen(community);

    ss = snmp_open(&session);
    if (!ss) {
        fprintf(stderr, "{\"error\":\"Failed to open SNMP session to %s\"}\\n", target);
        return 2;
    }

    char *sysName = snmp_get_str(ss, ".1.3.6.1.2.1.1.5.0");
    char *sysUp = snmp_get_str(ss, ".1.3.6.1.2.1.1.3.0");
    char *memTotal_str = snmp_get_str(ss, ".1.3.6.1.4.1.2021.4.5.0"); /* UCD-SNMP hrMemorySize may vary */
    char *memAvail_str = snmp_get_str(ss, ".1.3.6.1.4.1.2021.4.6.0"); /* memAvailReal */
    int interfaces_down = 0;
    char *parts[256];
    int parts_count = 0;
    int ifcount = snmp_walk_interfaces(ss, parts, &parts_count, &interfaces_down);

    int mem_percent = -1;
    if (memTotal_str && memAvail_str) {
        long total = atol(memTotal_str);
        long avail = atol(memAvail_str);
        if (total > 0) mem_percent = (int)(100.0 * (total - avail) / total + 0.5);
    }

    /* Build JSON output */
    printf("{");
    printf("\"ip\":\"%s\",", target);
    printf("\"sysName\":%s,", sysName ? ("\"" ) : "null");
    if (sysName) { printf("\"%s\",", sysName); } else printf("null,");
    printf("\"sysUpTime\":%s,", sysUp ? "\"" : "null");
    if (sysUp) { printf("\"%s\",", sysUp); } else printf("null,");
    printf("\"interfaces\":[");
    for (int i=0;i<parts_count;i++) {
        printf("%s", parts[i]);
        if (i<parts_count-1) printf(",");
        free(parts[i]);
    }
    printf("],");
    printf("\"if_count\":%d,", ifcount);
    printf("\"interfaces_down\":%d,", interfaces_down);
    if (mem_percent >=0) printf("\"memory_percent\":%d,", mem_percent);
    else printf("\"memory_percent\":null,");

    /* simple anomaly detection */
    printf("\"anomalies\":[");
    int added = 0;
    if (interfaces_down>0) {
        printf("\"%d_interface_down\"", interfaces_down); added++;
    }
    if (mem_percent >= 80) {
        if (added) printf(",");
        printf("\"high_memory_usage\""); added++;
    }
    printf("]");

    printf("}\\n");

    if (sysName) free(sysName);
    if (sysUp) free(sysUp);
    if (memTotal_str) free(memTotal_str);
    if (memAvail_str) free(memAvail_str);

    snmp_close(ss);
    SOCK_CLEANUP;
    return 0;
}
