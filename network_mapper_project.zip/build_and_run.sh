#!/bin/bash
set -e
echo "Installing prerequisites..."
sudo apt update
sudo apt install -y build-essential libsnmp-dev snmp snmpd python3-pip
pip3 install -r requirements.txt
echo "Compiling C scanner..."
gcc snmp_scan.c -o snmp_scan -lnetsnmp -lnetsnmpagent -lnetsnmphelpers || gcc snmp_scan.c -o snmp_scan -lnetsnmp
echo "Done. To run GUI: python3 gui.py"
